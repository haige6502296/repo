create view officesinfo_view as
select `customersample`.`offices`.`officeCode` AS `officeCode`, `customersample`.`offices`.`phone` AS `phone`, `customersample`.`offices`.`city` AS `city`
from `customersample`.`offices`;

