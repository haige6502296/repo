create
  definer = root@localhost procedure uselike_wildcard()
BEGIN
  SELECT * from products where productCode LIKE '%#_20%' ESCAPE '#';
END;

