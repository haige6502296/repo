create
  definer = root@localhost procedure getOrderCountByCustomerNumber(IN cust_no int, OUT shipped int, OUT canceled int, OUT resolved int, OUT disputed int)
BEGIN
	#shipped
	SELECT COUNT(*) INTO shipped FROM orders WHERE customerNumber=cust_no AND
	status='Shipped';
	
	#canceled
	SELECT count(*) into canceled FROM orders WHERE customerNumber=cust_no AND
	status='Cancelled';
	
		#resolved
	SELECT count(*) into canceled FROM orders WHERE customerNumber=cust_no AND
	status='Resolved';
	
	#disputed
	SELECT count(*) into disputed FROM orders WHERE customerNumber=cust_no AND
	status='Disputed';
END;

