create
  definer = root@localhost procedure set_counter(INOUT count int(4), IN inc int(4))
BEGIN
	#Routine body goes here...
set count=count+inc;
END;

