create view saleperorder as
select `customersample`.`orderdetails`.`orderNumber`                                                          AS `orderNumber`,
       sum((`customersample`.`orderdetails`.`quantityOrdered` * `customersample`.`orderdetails`.`priceEach`)) AS `total`
from `customersample`.`orderdetails`
group by `customersample`.`orderdetails`.`orderNumber`
order by `total` desc;

