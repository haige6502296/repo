create
  definer = root@localhost procedure CountStatus(OUT CountShipped int, OUT CountCancelld int, OUT CountResolved int, OUT CountDisputed int, OUT CountonHold int,
                                                 OUT CountInProcess int)
BEGIN
	-- get count of the Shipped
	SELECT count(*) into CountShipped  from orders where `status`='Shipped' GROUP BY status;
-- get count of the Cancelld
  SELECT count(*) into CountCancelld from orders where `status`='Cancelled' GROUP BY status;
	-- get count of the Resolved
  SELECT count(*) into CountResolved from orders where `status`='Resolved' GROUP BY status;
	-- get count of the Disputed
  SELECT count(*) into CountDisputed from orders where `status`='Disputed' GROUP BY status;
	-- get count of the On Hold
  SELECT count(*) into CountonHold from orders where `status`='On Hold' GROUP BY status;
	-- get count of the In Process
  SELECT count(*) into CountInProcess from orders where `status`='In Process' GROUP BY status;
	-- 使用6个out模式参数输出全部订单的状态合计情况

END;

