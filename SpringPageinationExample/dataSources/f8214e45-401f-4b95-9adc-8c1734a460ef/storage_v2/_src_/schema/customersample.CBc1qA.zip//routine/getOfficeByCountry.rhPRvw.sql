create
  definer = root@localhost procedure getOfficeByCountry(IN countryName varchar(255))
BEGIN
	#Routine body goes here...
SELECT * from offices WHERE country=countryName;
END;

