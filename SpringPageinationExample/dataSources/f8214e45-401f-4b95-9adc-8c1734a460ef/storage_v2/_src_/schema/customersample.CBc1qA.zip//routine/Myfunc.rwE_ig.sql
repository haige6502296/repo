create
  definer = root@localhost procedure Myfunc()
BEGIN
  SELECT * from products where productCode LIKE "%\_20%";

END;

