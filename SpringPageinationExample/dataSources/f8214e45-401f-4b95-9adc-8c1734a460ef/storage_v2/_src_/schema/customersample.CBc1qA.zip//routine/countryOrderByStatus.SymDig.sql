create
  definer = root@localhost procedure countryOrderByStatus(IN orderStatus varchar(25), OUT total int(20))
BEGIN
	#Routine body goes here...
SELECT count(orderNumber) INTO total from orders
where status=orderStatus;
END;

