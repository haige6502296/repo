create view payments_view as
select sum(`customersample`.`payments`.`amount`) AS `total`
from `customersample`.`payments`;

