create
  definer = root@localhost procedure getCustomerLevel(IN p_customerNumber int, OUT p_customerLevel varchar(10))
BEGIN
	DECLARE creditlim int;
	
	SELECT creditLimit INTO creditlim FROM customers
	WHERE customerNumber=P_customerNumber;
	
	if creditlim>50000 then
	set p_customerLevel='platinum';
	ELSEIF (creditlim<=50000 and creditlim>=10000)then
	set p_customerlevel='gold';
	
	ELSEIF (creditlim<10000)then
	set p_customerlevel='silver';
	
	end if;

END;

