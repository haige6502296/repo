create view bigsaleorder as
select round(`saleperorder`.`total`, 2) AS `total`
from `customersample`.`saleperorder`
where (`saleperorder`.`total` > 60000);

