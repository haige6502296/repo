create
  definer = root@localhost procedure assign()
BEGIN
  DECLARE total_count int DEFAULT 0;
	-- set total_count=10;这是一种赋值方法
	-- SELECT COUNT(*) information_schema total_count FROM products;这是另一种赋值方法
	SELECT COUNT(*)INTO total_count FROM products;
END;

